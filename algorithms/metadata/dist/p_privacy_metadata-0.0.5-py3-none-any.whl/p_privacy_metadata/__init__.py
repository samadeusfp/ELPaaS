from p_privacy_metadata import ELA, privacyExtension

__name__ = 'p_privacy_metadata'
__version__ = '0.0.5'
__doc__ = "Privacy metadata in process mining"
__author__ = 'Majid Rafiei'
__author_email__ = 'majid.rafiei@pads.rwth-aachen.de'
__maintainer__ = 'Majid Rafiei'
__maintainer_email__ = "majid.rafiei@pads.rwth-aachen.de"
